package com.example.curved_navigation

import io.flutter.embedding.android.FlutterActivity

class MainActivity: FlutterActivity() {
}
