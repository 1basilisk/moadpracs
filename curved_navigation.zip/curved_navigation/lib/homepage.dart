//importing pages
import 'package:curved_navigation/pages/home2.dart';
import 'package:curved_navigation/pages/home1.dart';
// import 'package:curver_nav_bar/pages/home4.dart';
// import 'package:curver_nav_bar/pages/homepage1.dart';
//importing packages
import 'package:curved_navigation_bar/curved_navigation_bar.dart';
import 'package:flutter/material.dart';

class HomePage extends StatefulWidget {
  const HomePage({Key? key}) : super(key: key);
  @override
  State<HomePage> createState() => _HomePageState();
} //Stateful Widget

class _HomePageState extends State<HomePage> {
  int index = 0;
  final screens = [
    HomePage1(),
    HomePage2(),
  ];
  @override
  Widget build(BuildContext context) {
    return Scaffold(
      backgroundColor: Colors.grey,
      body: screens[index],
      bottomNavigationBar: CurvedNavigationBar(
        height: 60,
        backgroundColor: Colors.white,
        color: Color.fromARGB(255, 9, 28, 55),
        animationDuration: Duration(milliseconds: 300),
        items: <Widget>[
          Icon(
            Icons.home,
            color: Colors.white,
            size: 25,
          ), //Icon
          Icon(
            Icons.security,
            color: Colors.white,
            size: 25,
          ), //Icon
          //   Icon(
          //     Icons.work,
          //     color: Colors.white,
          //     size: 25,
          //   ), //Icon
          //   Icon(
          //     Icons.school,
          //     color: Colors.white,
          //     size: 25,
          //   ),
        ],
        index: index,
        onTap: (index) => setState(() => this.index = index),
      ),
    );
  }
}